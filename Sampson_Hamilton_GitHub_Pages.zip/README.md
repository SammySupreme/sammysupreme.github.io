# Sampson Hamilton — Student Portfolio

This repository contains a professional personal website for CPSC 20000 — Introduction to Computer Science. The site introduces my academic interests, developing skills, selected coursework, and professional goals.

## Website

Intended GitHub Pages address: https://sammysupreme.github.io/

## Repository files

- `index.html` — the content and semantic structure of the website.
- `styles.css` — the visual design, responsive layout, and keyboard focus styles.
- `README.md` — project documentation.

## Accessibility and privacy

The site uses a logical heading hierarchy, descriptive links, a keyboard-accessible skip link, visible focus indicators, and responsive styling. It avoids publishing private contact details, student identification numbers, or other sensitive information.

## Development and publishing

The website uses the instructor-provided HTML and CSS starter structure with AI-assisted personalization and styling adjustments. To preview locally, keep `index.html` and `styles.css` in the same folder and open `index.html` in a browser. GitHub Pages is configured through the repository's Settings > Pages using the `main` branch and `/(root)` folder.

Live accessibility and link testing should be completed after publishing, and any issues should be corrected before submission.
